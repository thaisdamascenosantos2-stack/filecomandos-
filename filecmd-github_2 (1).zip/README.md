# filecmd — Organizador de Comandos

> Referência interativa de comandos de terminal com login, banco de dados e 52 comandos prontos para copiar.

## ✨ Funcionalidades

- Login & Cadastro com validação
- Banco de dados de usuários (localStorage)
- Painel Admin com estatísticas e exportação JSON
- Perfil completo com estatísticas do usuário
- Configurações: cor de destaque, cards compactos, badges, animações
- Favoritos por usuário (☆ em cada card e no modal)
- Histórico de cópias com timestamp
- 52 comandos em 6 categorias com flags e exemplos

## 📦 Como publicar no GitHub Pages

1. Crie um repositório **`filecmd`** no GitHub
2. Upload do `index.html` e `README.md`
3. Settings → Pages → Source: main → Save
4. Acesse: `https://SEU_USUARIO.github.io/filecmd`

## 🚀 Netlify Drop (mais rápido)

1. Acesse app.netlify.com/drop
2. Arraste o `index.html`
3. Link gerado na hora

---
Feito com ⌘ para devs
